
  # Create Home Page Frame

  This is a code bundle for Create Home Page Frame. The original project is available at https://www.figma.com/design/1PyIAShwnEQ0lKJ4PvBNro/Create-Home-Page-Frame.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  