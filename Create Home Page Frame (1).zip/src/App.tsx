import { useState } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { HeroCarousel } from './components/HeroCarousel';
import { TrendingBooks } from './components/TrendingBooks';
import { NewArrivals } from './components/NewArrivals';
import { RelatedBooks } from './components/RelatedBooks';
import { Footer } from './components/Footer';
import { BookDetail } from './components/BookDetail';
import { Checkout } from './components/Checkout';
import { PaymentSuccess } from './components/PaymentSuccess';
import { OrderTracking } from './components/OrderTracking';
import { Cart, CartItem } from './components/Cart';
import { Toaster } from './components/ui/sonner';
import { getBookById, getRelatedBooks } from './data/booksData';
import { toast } from 'sonner@2.0.3';

type AppView = 'home' | 'detail' | 'checkout' | 'payment-success' | 'tracking' | 'cart';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [selectedBookId, setSelectedBookId] = useState<number | null>(null);
  const [orderDetails, setOrderDetails] = useState<{ quantity: number; total: number } | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleBookClick = (bookId: number) => {
    setSelectedBookId(bookId);
    setCurrentView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setSelectedBookId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBuyNow = () => {
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromCheckout = () => {
    setCurrentView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePaymentComplete = (quantity: number, total: number) => {
    setOrderDetails({ quantity, total });
    setCurrentView('payment-success');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePaymentSuccessComplete = () => {
    setCurrentView('tracking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (bookId: number, quantity: number = 1) => {
    const book = getBookById(bookId);
    if (!book) return;

    setCartItems((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === bookId);
      
      if (existingItem) {
        toast.success(`Updated ${book.title} quantity in cart`);
        return prevCart.map((item) =>
          item.id === bookId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        toast.success(`Added ${book.title} to cart`);
        return [
          ...prevCart,
          {
            id: book.id,
            title: book.title,
            price: book.price,
            image: book.image,
            quantity,
          },
        ];
      }
    });
  };

  const handleUpdateCartQuantity = (bookId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setCartItems((prevCart) =>
      prevCart.map((item) =>
        item.id === bookId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveFromCart = (bookId: number) => {
    const book = getBookById(bookId);
    setCartItems((prevCart) => prevCart.filter((item) => item.id !== bookId));
    if (book) {
      toast.success(`Removed ${book.title} from cart`);
    }
  };

  const handleCartClick = () => {
    setCurrentView('cart');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCheckoutFromCart = (bookId: number) => {
    setSelectedBookId(bookId);
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const selectedBook = selectedBookId ? getBookById(selectedBookId) : null;
  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white">
      <Header cartItemCount={cartItemCount} onCartClick={handleCartClick} />
      <Navigation />
      
      {currentView === 'home' && (
        <main>
          <HeroCarousel />
          <TrendingBooks 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
          <NewArrivals 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
          <RelatedBooks 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
        </main>
      )}

      {currentView === 'detail' && selectedBook && (
        <BookDetail
          book={selectedBook}
          relatedBooks={getRelatedBooks(selectedBookId!)}
          onBack={handleBackToHome}
          onBookClick={handleBookClick}
          onBuyNow={handleBuyNow}
          onAddToCart={handleAddToCart}
          onAddRelatedToCart={(bookId) => handleAddToCart(bookId, 1)}
        />
      )}

      {currentView === 'cart' && (
        <Cart
          cartItems={cartItems}
          onUpdateQuantity={handleUpdateCartQuantity}
          onRemoveItem={handleRemoveFromCart}
          onBack={handleBackToHome}
          onCheckout={handleCheckoutFromCart}
        />
      )}

      {currentView === 'checkout' && selectedBook && (
        <Checkout
          book={selectedBook}
          onBack={handleBackFromCheckout}
          onPaymentComplete={handlePaymentComplete}
        />
      )}

      {currentView === 'payment-success' && orderDetails && (
        <PaymentSuccess
          totalAmount={orderDetails.total}
          onComplete={handlePaymentSuccessComplete}
        />
      )}

      {currentView === 'tracking' && selectedBook && orderDetails && (
        <OrderTracking
          book={selectedBook}
          quantity={orderDetails.quantity}
          totalAmount={orderDetails.total}
          onBackToHome={handleBackToHome}
        />
      )}
      
      {currentView !== 'payment-success' && <Footer />}
    </div>
  );
}
