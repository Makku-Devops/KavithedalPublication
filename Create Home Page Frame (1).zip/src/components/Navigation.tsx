import { MessageCircle, BookOpen } from 'lucide-react';

export function Navigation() {
  return (
    <nav className="bg-white border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-emerald-800" />
            <span className="text-emerald-800">Kavithalai Books</span>
          </div>
          
          <ul className="flex items-center gap-12">
            <li>
              <a href="#" className="text-gray-900 hover:text-emerald-800 transition-colors">
                Home
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-900 hover:text-emerald-800 transition-colors">
                Books
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-900 hover:text-emerald-800 transition-colors">
                Contact us
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-900 hover:text-emerald-800 transition-colors">
                Category
              </a>
            </li>
            <li>
              <a href="#" className="text-emerald-600 hover:text-emerald-800 transition-colors">
                <MessageCircle className="w-5 h-5 fill-current" />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
