import { BookCard } from './BookCard';

export const trendingBooks = [
  {
    id: 1,
    title: 'காலியாகாரின் முகங்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1664793937878-4b663ff216f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjByZWR8ZW58MXx8fHwxNzYxMzczMjU5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
  },
  {
    id: 2,
    title: 'வெண்முரசு சாரல்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1674154642704-0a4f0bdcb676?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBkYXJrfGVufDF8fHx8MTc2MTM3MzI1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
  },
  {
    id: 3,
    title: 'படப்புச்சி விஷயங்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1705837861201-dd000d929a31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBncmVlbnxlbnwxfHx8fDE3NjEzNzMyNTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: true,
  },
  {
    id: 4,
    title: 'எண்ணங்கள் சந்திக்க கற்றுக்கள் வார்த்தை',
    price: 200,
    image: 'https://images.unsplash.com/photo-1604530747895-5c54309b905c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBhcnRpc3RpY3xlbnwxfHx8fDE3NjEzNzMyNjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
  },
];

interface TrendingBooksProps {
  onBookClick: (bookId: number) => void;
  onAddToCart: (bookId: number) => void;
}

export function TrendingBooks({ onBookClick, onAddToCart }: TrendingBooksProps) {
  return (
    <section className="max-w-7xl mx-auto px-6 py-12">
      <h2 className="text-emerald-800 text-center mb-8">Trending Books</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {trendingBooks.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            price={book.price}
            image={book.image}
            onSale={book.onSale}
            onClick={() => onBookClick(book.id)}
            onAddToCart={(e) => {
              e.stopPropagation();
              onAddToCart(book.id);
            }}
          />
        ))}
      </div>
    </section>
  );
}
