import { useState } from 'react';
import { Share2, Minus, Plus, Twitter, Facebook, Linkedin, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { BookCard } from './BookCard';

interface BookDetailProps {
  book: {
    id: number;
    title: string;
    price: number;
    image: string;
    description?: string;
    author?: string;
    isbn?: string;
    pages?: number;
    format?: string;
    weight?: string;
    dimensions?: string;
  };
  relatedBooks: Array<{
    id: number;
    title: string;
    price: number;
    image: string;
    onSale: boolean;
  }>;
  onBack: () => void;
  onBookClick: (bookId: number) => void;
  onBuyNow: () => void;
  onAddToCart: (bookId: number, quantity: number) => void;
  onAddRelatedToCart: (bookId: number) => void;
}

export function BookDetail({ book, relatedBooks, onBack, onBookClick, onBuyNow, onAddToCart, onAddRelatedToCart }: BookDetailProps) {
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    onAddToCart(book.id, quantity);
  };

  const handleIncrement = () => {
    setQuantity(prev => prev + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Book Detail Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Book Image */}
          <div>
            <img
              src={book.image}
              alt={book.title}
              className="w-full max-w-sm mx-auto rounded-lg shadow-lg"
            />
          </div>

          {/* Book Info */}
          <div>
            <h1 className="text-emerald-800 mb-4">{book.title}</h1>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-emerald-800">₹ {book.price}</span>
            </div>
            <p className="text-gray-600 text-sm mb-6">Only 3 item(s) left in stock</p>

            {/* Quantity Selector */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border border-gray-300 rounded">
                <button
                  onClick={handleDecrement}
                  className="p-2 hover:bg-gray-100 transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-6 py-2 border-x border-gray-300">{quantity}</span>
                <button
                  onClick={handleIncrement}
                  className="p-2 hover:bg-gray-100 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <Button 
                onClick={handleAddToCart}
                className="bg-red-600 hover:bg-red-700 px-8"
              >
                ADD TO CART
              </Button>
            </div>

            <Button 
              onClick={onBuyNow}
              className="w-full bg-emerald-800 hover:bg-emerald-900 mb-6"
            >
              BUY NOW
            </Button>

            {/* Share Buttons */}
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-2 text-gray-700">
                <Share2 className="w-4 h-4" />
                Share
              </span>
              <button className="hover:text-emerald-600 transition-colors">
                <Twitter className="w-5 h-5" />
              </button>
              <button className="hover:text-emerald-600 transition-colors">
                <Facebook className="w-5 h-5" />
              </button>
              <button className="hover:text-emerald-600 transition-colors">
                <MessageCircle className="w-5 h-5" />
              </button>
              <button className="hover:text-emerald-600 transition-colors">
                <Linkedin className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mb-12">
          <h2 className="text-emerald-800 mb-4">Description</h2>
          <p className="text-gray-700 leading-relaxed">
            {book.description || 'உலகின் முதன்மையான ஒரு அதிசிய செய்தி அன்பு! அன்பே வாழ்க்கையின் முழுமையான இருக்கிறது. தாவீனியின் நிகழ்கள் நூல் இரு நிகழ்ச்சிகளையும் முழுமையாக கொண்டுள்ளது. முதலாம் நிகழ்வு சற்று புதிரானது, அதில் பல வித்தியாசமான செய்திகள் உள்ளன. இரண்டாம் நிகழ்வு முதலாம் நிகழ்வை விட தெளிவானது மற்றும் புரிந்து கொள்ள எளிதானது. இந்த நூல் வாசகர்களுக்கு ஒரு புதிய அனுபவத்தை வழங்கும் என்று நம்புகிறோம்.'}
          </p>
        </div>

        {/* Additional Information */}
        <div className="mb-12">
          <h2 className="text-emerald-800 mb-4">Additional Information</h2>
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full">
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Weight</td>
                  <td className="py-3 px-4">{book.weight || '0.2 g'}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Dimensions</td>
                  <td className="py-3 px-4">{book.dimensions || '8.3 × 5.3 × 0.6 cm'}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Author</td>
                  <td className="py-3 px-4">{book.author || 'மருதமுத்து செல்வராஜ் செல்வம், முன்னுரை: சித்திக்'}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Pages</td>
                  <td className="py-3 px-4">{book.pages || 120}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Format</td>
                  <td className="py-3 px-4">{book.format || 'Paperback'}</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 bg-gray-50">ISBN</td>
                  <td className="py-3 px-4">{book.isbn || '9789384303181'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Reviews */}
        <div className="mb-12">
          <h2 className="text-emerald-800 mb-6">Review(s)</h2>
          
          <div className="flex items-start gap-12 mb-8">
            <div className="text-center">
              <div className="mb-2">0.00</div>
              <div className="flex gap-1 text-gray-300">
                {[1, 2, 3, 4, 5].map(star => (
                  <span key={star}>★</span>
                ))}
              </div>
              <div className="text-gray-600 text-sm mt-2">0 Review(s)</div>
            </div>

            <div className="flex-1 space-y-2">
              {[5, 4, 3, 2, 1].map(rating => (
                <div key={rating} className="flex items-center gap-3">
                  <span className="w-4">{rating}</span>
                  <span className="text-yellow-500">★</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '0%' }}></div>
                  </div>
                  <span className="w-8 text-right text-gray-600">0</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Related Books */}
        <div>
          <h2 className="text-emerald-800 text-center mb-8">Related Books</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedBooks.map((relatedBook) => (
              <BookCard
                key={relatedBook.id}
                title={relatedBook.title}
                price={relatedBook.price}
                image={relatedBook.image}
                onSale={relatedBook.onSale}
                onClick={() => onBookClick(relatedBook.id)}
                onAddToCart={(e) => {
                  e.stopPropagation();
                  onAddRelatedToCart(relatedBook.id);
                }}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
