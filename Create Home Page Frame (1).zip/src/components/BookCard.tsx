import { ImageWithFallback } from './figma/ImageWithFallback';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ShoppingCart } from 'lucide-react';

interface BookCardProps {
  title: string;
  price: number;
  image: string;
  onSale?: boolean;
  onClick?: () => void;
  onAddToCart?: (e: React.MouseEvent) => void;
}

export function BookCard({ title, price, image, onSale = false, onClick, onAddToCart }: BookCardProps) {
  return (
    <div className="flex flex-col gap-3 group">
      <div className="relative aspect-[2/3] overflow-hidden rounded-lg shadow-md group-hover:shadow-xl transition-shadow cursor-pointer" onClick={onClick}>
        {onSale && (
          <Badge className="absolute top-2 left-2 bg-emerald-600 hover:bg-emerald-600 z-10">
            Sale
          </Badge>
        )}
        <ImageWithFallback
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex flex-col gap-2">
        <div className="cursor-pointer" onClick={onClick}>
          <h3 className="text-gray-900 line-clamp-2">{title}</h3>
          <p className="text-gray-900">₹ {price}</p>
        </div>
        {onAddToCart && (
          <Button
            onClick={onAddToCart}
            size="sm"
            className="bg-emerald-700 hover:bg-emerald-800 w-full"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        )}
      </div>
    </div>
  );
}
