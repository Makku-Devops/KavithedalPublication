import { Input } from './ui/input';
import { Button } from './ui/button';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-emerald-800 text-white py-12 mt-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Company Details */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="mb-4">About Us</h3>
            <p className="text-emerald-100 text-sm">
              Kavithalai Books is your premier destination for Tamil literature, offering a wide collection of books, novels, and publications.
            </p>
          </div>
          
          <div>
            <h3 className="mb-4">Quick Links</h3>
            <ul className="space-y-2 text-emerald-100 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Books</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Categories</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">About</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="mb-4">Contact Info</h3>
            <ul className="space-y-3 text-emerald-100 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>123 Book Street, Chennai, Tamil Nadu - 600001</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span>info@kavithalaibooks.com</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="mb-4">Follow Us</h3>
            <div className="flex gap-4 mb-4">
              <a href="#" className="hover:text-emerald-200 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-emerald-200 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-emerald-200 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
        
        {/* Newsletter Subscription */}
        <div className="border-t border-emerald-700 pt-8">
          <div className="text-center mb-4">
            <h3 className="mb-2">Subscribe to Our Newsletter</h3>
            <p className="text-emerald-100 text-sm">Stay updated with new arrivals and special offers</p>
          </div>
          <div className="flex items-center justify-center gap-2 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              className="bg-white border-0"
            />
            <Button className="bg-red-600 hover:bg-red-700 px-6">
              Subscribe
            </Button>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-emerald-700 mt-8 pt-6 text-center text-emerald-100 text-sm">
          <p>&copy; 2025 Kavithalai Books. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
