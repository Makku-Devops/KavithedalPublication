import { useState, useEffect } from 'react';
import { X, Upload, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Slider } from './ui/slider';

interface Book {
  id: number;
  title: string;
  price: number;
  image: string;
  onSale: boolean;
  offer?: string;
  category: string;
  isFeatured?: boolean;
  offerPercentage?: number;
  description?: string;
  author?: string;
  isbn?: string;
  pages?: number;
  format?: string;
}

interface AddBookFormProps {
  book?: Book | null;
  onSave: (book: Book) => void;
  onCancel: () => void;
}

const categories = [
  { value: 'fiction', label: 'Fiction' },
  { value: 'poetry', label: 'Poetry' },
  { value: 'literature', label: 'Literature' },
  { value: 'biography', label: 'Biography' },
  { value: 'history', label: 'History' },
  { value: 'other', label: 'Other' },
];

export function AddBookForm({ book, onSave, onCancel }: AddBookFormProps) {
  const [formData, setFormData] = useState<Partial<Book>>({
    title: '',
    price: 0,
    image: '',
    onSale: false,
    category: 'fiction',
    isFeatured: false,
    offerPercentage: 0,
    description: '',
    author: '',
    isbn: '',
    pages: 0,
    format: 'Paperback',
  });

  useEffect(() => {
    if (book) {
      setFormData(book);
    }
  }, [book]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const bookToSave: Book = {
      id: book?.id || Date.now(),
      title: formData.title || '',
      price: formData.price || 0,
      image: formData.image || 'https://images.unsplash.com/photo-1664793937878-4b663ff216f3?w=400',
      onSale: formData.onSale || false,
      category: formData.category || 'fiction',
      isFeatured: formData.isFeatured || false,
      offerPercentage: formData.offerPercentage || 0,
      offer: formData.offerPercentage && formData.offerPercentage > 0 
        ? `${formData.offerPercentage}% OFF` 
        : undefined,
      description: formData.description,
      author: formData.author,
      isbn: formData.isbn,
      pages: formData.pages,
      format: formData.format,
    };

    onSave(bookToSave);
  };

  const calculateDiscountedPrice = () => {
    if (!formData.price || !formData.offerPercentage) return formData.price || 0;
    return Math.round(formData.price - (formData.price * formData.offerPercentage / 100));
  };

  return (
    <div className="bg-white rounded-lg shadow-lg border-2 border-emerald-700 overflow-hidden">
      <div className="bg-emerald-700 text-white p-6 flex items-center justify-between">
        <h2 className="text-white">{book ? 'Edit Book' : 'Add New Book'}</h2>
        <button
          onClick={onCancel}
          className="w-8 h-8 rounded-full hover:bg-emerald-600 flex items-center justify-center transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            <div>
              <Label htmlFor="title">Book Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Enter book title"
                required
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="author">Author *</Label>
              <Input
                id="author"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                placeholder="Enter author name"
                required
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="price">Original Price (₹) *</Label>
              <Input
                id="price"
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                placeholder="Enter price"
                required
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="offerPercentage">
                Offer Percentage: {formData.offerPercentage}%
              </Label>
              <Slider
                id="offerPercentage"
                value={[formData.offerPercentage || 0]}
                onValueChange={(value) => setFormData({ ...formData, offerPercentage: value[0] })}
                max={90}
                step={5}
                className="mt-4"
              />
              {formData.offerPercentage && formData.offerPercentage > 0 && (
                <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded">
                  <p className="text-sm text-green-800">
                    Original Price: ₹{formData.price}
                  </p>
                  <p className="text-sm">
                    <strong className="text-green-800">
                      Discounted Price: ₹{calculateDiscountedPrice()}
                    </strong>
                  </p>
                  <p className="text-sm text-green-700">
                    Savings: ₹{formData.price - calculateDiscountedPrice()}
                  </p>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="category">Category *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="isbn">ISBN</Label>
              <Input
                id="isbn"
                value={formData.isbn}
                onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                placeholder="Enter ISBN"
                className="mt-2"
              />
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <div>
              <Label htmlFor="image">Image URL *</Label>
              <Input
                id="image"
                value={formData.image}
                onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                placeholder="Enter image URL"
                required
                className="mt-2"
              />
              {formData.image && (
                <div className="mt-3">
                  <img
                    src={formData.image}
                    alt="Preview"
                    className="w-32 h-48 object-cover rounded border-2 border-gray-200"
                  />
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="pages">Number of Pages</Label>
              <Input
                id="pages"
                type="number"
                value={formData.pages}
                onChange={(e) => setFormData({ ...formData, pages: Number(e.target.value) })}
                placeholder="Enter number of pages"
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="format">Format</Label>
              <Select
                value={formData.format}
                onValueChange={(value) => setFormData({ ...formData, format: value })}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Paperback">Paperback</SelectItem>
                  <SelectItem value="Hardcover">Hardcover</SelectItem>
                  <SelectItem value="eBook">eBook</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2">
                <Star className={`w-5 h-5 ${formData.isFeatured ? 'fill-yellow-500 text-yellow-500' : 'text-gray-400'}`} />
                <Label htmlFor="featured">Mark as Featured</Label>
              </div>
              <Switch
                id="featured"
                checked={formData.isFeatured}
                onCheckedChange={(checked) => setFormData({ ...formData, isFeatured: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <Label htmlFor="onSale">On Sale</Label>
              <Switch
                id="onSale"
                checked={formData.onSale}
                onCheckedChange={(checked) => setFormData({ ...formData, onSale: checked })}
              />
            </div>
          </div>
        </div>

        {/* Description - Full Width */}
        <div className="mt-6">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Enter book description"
            rows={4}
            className="mt-2"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mt-8">
          <Button
            type="submit"
            className="flex-1 bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all"
          >
            {book ? 'Update Book' : 'Add Book'}
          </Button>
          <Button
            type="button"
            onClick={onCancel}
            variant="outline"
            className="flex-1 hover:scale-105 transition-all"
          >
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}
