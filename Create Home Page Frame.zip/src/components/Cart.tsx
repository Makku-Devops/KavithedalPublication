import { motion } from 'motion/react';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';

export interface CartItem {
  id: number;
  title: string;
  price: number;
  image: string;
  quantity: number;
}

interface CartProps {
  cartItems: CartItem[];
  onUpdateQuantity: (bookId: number, newQuantity: number) => void;
  onRemoveItem: (bookId: number) => void;
  onBack: () => void;
  onCheckout: (bookId: number) => void;
}

export function Cart({ cartItems, onUpdateQuantity, onRemoveItem, onBack, onCheckout }: CartProps) {
  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shippingCost = cartItems.length > 0 ? 50 : 0;
  const total = subtotal + shippingCost;

  const handleIncrement = (bookId: number, currentQuantity: number) => {
    onUpdateQuantity(bookId, currentQuantity + 1);
  };

  const handleDecrement = (bookId: number, currentQuantity: number) => {
    if (currentQuantity > 1) {
      onUpdateQuantity(bookId, currentQuantity - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8">
          <Button
            onClick={onBack}
            variant="ghost"
            className="mb-4 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50 hover:scale-105 transition-all"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Continue Shopping
          </Button>
          <h1 className="text-emerald-700">Shopping Cart</h1>
          <p className="text-gray-600 mt-2">
            {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} in your cart
          </p>
        </div>

        {cartItems.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg border-2 border-emerald-700 p-12 text-center"
          >
            <ShoppingBag className="w-24 h-24 text-gray-300 mx-auto mb-4" />
            <h2 className="text-gray-700 mb-2">Your cart is empty</h2>
            <p className="text-gray-500 mb-6">Add some books to get started!</p>
            <Button
              onClick={onBack}
              className="bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all"
            >
              Browse Books
            </Button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-lg border-2 border-emerald-700 p-6"
                >
                  <div className="flex gap-6">
                    {/* Book Image */}
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-24 h-32 object-cover rounded"
                    />

                    {/* Book Details */}
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="mb-2">{item.title}</h3>
                          <p className="text-emerald-700">₹ {item.price}</p>
                        </div>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-red-600 hover:text-red-700 transition-colors p-2"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => handleDecrement(item.id, item.quantity)}
                            className="w-8 h-8 rounded-full border-2 border-emerald-700 flex items-center justify-center hover:bg-emerald-50 transition-colors"
                          >
                            <Minus className="w-4 h-4 text-emerald-700" />
                          </button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => handleIncrement(item.id, item.quantity)}
                            className="w-8 h-8 rounded-full border-2 border-emerald-700 flex items-center justify-center hover:bg-emerald-50 transition-colors"
                          >
                            <Plus className="w-4 h-4 text-emerald-700" />
                          </button>
                        </div>

                        <div className="text-right">
                          <p className="text-gray-500 text-sm">Subtotal</p>
                          <p className="text-red-600">₹ {item.price * item.quantity}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-lg border-2 border-emerald-700 p-6 sticky top-6"
              >
                <h2 className="text-emerald-700 mb-6">Order Summary</h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-gray-700">
                    <span>Subtotal ({cartItems.length} items)</span>
                    <span>₹ {subtotal}</span>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>Shipping</span>
                    <span>₹ {shippingCost}</span>
                  </div>
                  <div className="border-t-2 border-gray-200 pt-4">
                    <div className="flex justify-between">
                      <span>Total</span>
                      <span className="text-red-600">₹ {total}</span>
                    </div>
                  </div>
                </div>

                {cartItems.length === 1 ? (
                  <Button
                    onClick={() => onCheckout(cartItems[0].id)}
                    className="w-full bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all"
                  >
                    Proceed to Checkout
                  </Button>
                ) : (
                  <div>
                    <p className="text-sm text-gray-600 mb-4 text-center">
                      Select an item to checkout individually
                    </p>
                    <div className="space-y-2">
                      {cartItems.map((item) => (
                        <Button
                          key={item.id}
                          onClick={() => onCheckout(item.id)}
                          variant="outline"
                          className="w-full border-emerald-700 text-emerald-700 hover:bg-emerald-50 hover:scale-105 transition-all"
                        >
                          Checkout {item.title.slice(0, 20)}...
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mt-4 p-4 bg-emerald-50 rounded-lg">
                  <p className="text-sm text-emerald-800">
                    Free shipping on orders over ₹ 500
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
