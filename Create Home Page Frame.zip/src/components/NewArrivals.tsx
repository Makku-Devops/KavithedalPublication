import { BookCard } from './BookCard';

export const newArrivals = [
  {
    id: 5,
    title: 'புதிய காலத்து கவிதைகள்',
    price: 350,
    image: 'https://images.unsplash.com/photo-1614708403338-cdf1914fb117?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBvcmFuZ2V8ZW58MXx8fHwxNzYxMzA0NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: true,
    offer: '25% OFF',
  },
  {
    id: 6,
    title: 'இலக்கியத்தின் ஒளி',
    price: 450,
    image: 'https://images.unsplash.com/photo-1622481168506-3cce81c393c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjB5ZWxsb3d8ZW58MXx8fHwxNzYxMzczNjM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
    offer: 'NEW',
  },
  {
    id: 7,
    title: 'கனவுகளின் பாதை',
    price: 280,
    image: 'https://images.unsplash.com/photo-1643913398973-f8e24bf6d1c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBwdXJwbGV8ZW58MXx8fHwxNzYxMzczNjM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
  },
  {
    id: 8,
    title: 'உணர்வுகளின் நாவல்',
    price: 320,
    image: 'https://images.unsplash.com/photo-1615976909545-a2d402c7dac3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBwaW5rfGVufDF8fHx8MTc2MTM3MzYzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
    offer: 'NEW',
  },
];

interface NewArrivalsProps {
  onBookClick: (bookId: number) => void;
  onAddToCart: (bookId: number) => void;
}

export function NewArrivals({ onBookClick, onAddToCart }: NewArrivalsProps) {
  return (
    <section className="max-w-7xl mx-auto px-6 py-12 bg-gray-50">
      <h2 className="text-emerald-800 text-center mb-8">New Arrivals</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {newArrivals.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            price={book.price}
            image={book.image}
            onSale={book.onSale}
            offer={book.offer}
            offerPercentage={book.offerPercentage}
            isFeatured={book.isFeatured}
            onClick={() => onBookClick(book.id)}
            onAddToCart={(e) => {
              e.stopPropagation();
              onAddToCart(book.id);
            }}
          />
        ))}
      </div>
    </section>
  );
}
