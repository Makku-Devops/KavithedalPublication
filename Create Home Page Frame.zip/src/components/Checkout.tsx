import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CreditCard, Building2, Smartphone, Trash2, Plus, Minus } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface CheckoutProps {
  book: {
    id: number;
    title: string;
    price: number;
    image: string;
  };
  onBack: () => void;
  onPaymentComplete: (quantity: number, total: number) => void;
}

type PaymentMethod = 'upi' | 'card' | 'online';

export function Checkout({ book, onBack, onPaymentComplete }: CheckoutProps) {
  const [quantity, setQuantity] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  
  const shippingCost = 50;
  const subTotal = book.price * quantity;
  const total = subTotal + shippingCost;

  const handlePayment = () => {
    if (paymentMethod) {
      onPaymentComplete(quantity, total);
    }
  };

  const handleIncrement = () => {
    setQuantity(prev => prev + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  const handleDelete = () => {
    onBack();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Summary - Left Side */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border-2 border-emerald-700 p-6">
              <h2 className="text-emerald-700 mb-6">Order Summary</h2>
              
              <div className="flex gap-4 mb-6">
                <img
                  src={book.image}
                  alt={book.title}
                  className="w-24 h-32 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="mb-2">{book.title}</h3>
                  <p className="text-gray-900">₹ {book.price}</p>
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center border border-gray-300 rounded">
                  <button
                    onClick={handleDecrement}
                    className="px-3 py-1 hover:bg-gray-100 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-6 py-1 border-x border-gray-300">{quantity}</span>
                  <button
                    onClick={handleIncrement}
                    className="px-3 py-1 hover:bg-gray-100 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <button
                  onClick={handleDelete}
                  className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3 border-t pt-4">
                <div className="flex justify-between">
                  <span>Sub Total</span>
                  <span>₹ {subTotal}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>₹ {shippingCost}</span>
                </div>
                <div className="flex justify-between border-t pt-3">
                  <span>Total</span>
                  <span className="text-red-600">₹ {total}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Delivery & Payment */}
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery Details */}
            <div className="bg-white rounded-lg border-2 border-emerald-700 p-6">
              <h2 className="text-emerald-700 mb-6">Delivery Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="name">
                    Name<span className="text-red-600">*</span>
                  </Label>
                  <Input id="name" className="mt-1" />
                </div>
                
                <div>
                  <Label htmlFor="phone">
                    Phone No<span className="text-red-600">*</span>
                  </Label>
                  <Input id="phone" type="tel" className="mt-1" />
                </div>
                
                <div>
                  <Label htmlFor="email">
                    Email<span className="text-red-600">*</span>
                  </Label>
                  <Input id="email" type="email" className="mt-1" />
                </div>
                
                <div className="md:col-span-2">
                  <Label htmlFor="address">
                    Address<span className="text-red-600">*</span>
                  </Label>
                  <Input id="address" className="mt-1" />
                </div>
                
                <div>
                  <Label htmlFor="city">
                    City<span className="text-red-600">*</span>
                  </Label>
                  <Input id="city" className="mt-1" />
                </div>
                
                <div>
                  <Label htmlFor="pincode">
                    Pin code<span className="text-red-600">*</span>
                  </Label>
                  <Input id="pincode" className="mt-1" />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="bg-white rounded-lg border-2 border-emerald-700 p-6">
              <h2 className="text-emerald-700 mb-6">Payment Method</h2>
              
              <div className="grid grid-cols-3 gap-4 mb-6">
                <button
                  onClick={() => setPaymentMethod('upi')}
                  className={`flex flex-col items-center justify-center p-6 border-2 rounded-lg transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-emerald-700 bg-emerald-50'
                      : 'border-gray-300 hover:border-emerald-500'
                  }`}
                >
                  <Smartphone className="w-8 h-8 text-emerald-700 mb-2" />
                  <span className="text-emerald-700">UPI</span>
                </button>

                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`flex flex-col items-center justify-center p-6 border-2 rounded-lg transition-all ${
                    paymentMethod === 'card'
                      ? 'border-emerald-700 bg-emerald-50'
                      : 'border-gray-300 hover:border-emerald-500'
                  }`}
                >
                  <CreditCard className="w-8 h-8 text-emerald-700 mb-2" />
                  <span className="text-emerald-700">Card</span>
                </button>

                <button
                  onClick={() => setPaymentMethod('online')}
                  className={`flex flex-col items-center justify-center p-6 border-2 rounded-lg transition-all ${
                    paymentMethod === 'online'
                      ? 'border-emerald-700 bg-emerald-50'
                      : 'border-gray-300 hover:border-emerald-500'
                  }`}
                >
                  <Building2 className="w-8 h-8 text-emerald-700 mb-2" />
                  <span className="text-emerald-700">Online</span>
                </button>
              </div>
            </div>

            {/* Payment Details */}
            <div className="bg-white rounded-lg border-2 border-emerald-700 p-6 min-h-[300px]">
              <h2 className="text-emerald-700 mb-6">Payment Details</h2>
              
              <AnimatePresence mode="wait">
                {paymentMethod === 'upi' && (
                  <motion.div
                    key="upi"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="upi-id">UPI ID</Label>
                      <Input
                        id="upi-id"
                        placeholder="example@upi"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="upi-name">Name</Label>
                      <Input
                        id="upi-name"
                        placeholder="Enter your name"
                        className="mt-1"
                      />
                    </div>
                    <Button 
                      onClick={handlePayment}
                      className="w-full bg-emerald-700 hover:bg-emerald-800 mt-6"
                    >
                      Pay ₹ {total}
                    </Button>
                  </motion.div>
                )}

                {paymentMethod === 'card' && (
                  <motion.div
                    key="card"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="card-number">Card Number</Label>
                      <Input
                        id="card-number"
                        placeholder="1234 5678 9012 3456"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="card-name">Card Holder Name</Label>
                      <Input
                        id="card-name"
                        placeholder="Name on card"
                        className="mt-1"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input
                          id="expiry"
                          placeholder="MM/YY"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          placeholder="123"
                          type="password"
                          maxLength={3}
                          className="mt-1"
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={handlePayment}
                      className="w-full bg-emerald-700 hover:bg-emerald-800 mt-6"
                    >
                      Pay ₹ {total}
                    </Button>
                  </motion.div>
                )}

                {paymentMethod === 'online' && (
                  <motion.div
                    key="online"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="bank">Select Bank</Label>
                      <select
                        id="bank"
                        className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="">Choose your bank</option>
                        <option value="sbi">State Bank of India</option>
                        <option value="hdfc">HDFC Bank</option>
                        <option value="icici">ICICI Bank</option>
                        <option value="axis">Axis Bank</option>
                        <option value="kotak">Kotak Mahindra Bank</option>
                        <option value="pnb">Punjab National Bank</option>
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="account-name">Account Holder Name</Label>
                      <Input
                        id="account-name"
                        placeholder="Enter account holder name"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="account-number">Account Number</Label>
                      <Input
                        id="account-number"
                        placeholder="Enter account number"
                        className="mt-1"
                      />
                    </div>
                    <Button 
                      onClick={handlePayment}
                      className="w-full bg-emerald-700 hover:bg-emerald-800 mt-6"
                    >
                      Pay ₹ {total}
                    </Button>
                  </motion.div>
                )}

                {!paymentMethod && (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center justify-center h-48 text-gray-400"
                  >
                    Please select a payment method above
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
