import { useState } from 'react';
import { Share2, Minus, Plus, Twitter, Facebook, Linkedin, MessageCircle, Star, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { BookCard } from './BookCard';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { toast } from 'sonner@2.0.3';
import { motion } from 'motion/react';

interface BookDetailProps {
  book: {
    id: number;
    title: string;
    price: number;
    image: string;
    description?: string;
    author?: string;
    isbn?: string;
    pages?: number;
    format?: string;
    weight?: string;
    dimensions?: string;
  };
  relatedBooks: Array<{
    id: number;
    title: string;
    price: number;
    image: string;
    onSale: boolean;
  }>;
  onBack: () => void;
  onBookClick: (bookId: number) => void;
  onBuyNow: () => void;
  onAddToCart: (bookId: number, quantity: number) => void;
  onAddRelatedToCart: (bookId: number) => void;
}

interface Review {
  id: number;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export function BookDetail({ book, relatedBooks, onBack, onBookClick, onBuyNow, onAddToCart, onAddRelatedToCart }: BookDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: 1,
      userName: 'Rajesh Kumar',
      rating: 5,
      comment: 'அற்புதமான புத்தகம்! மிகவும் பயனுள்ளதாக இருந்தது. நிச்சயமாக பரிந்துரைக்கிறேன்.',
      date: '2025-01-15',
    },
    {
      id: 2,
      userName: 'Priya Sharma',
      rating: 4,
      comment: 'நல்ல புத்தகம். சில பகுதிகள் சிறப்பாக இருந்தன. தமிழ் இலக்கியத்தை விரும்புவர்களுக்கு நல்லது.',
      date: '2025-01-10',
    },
  ]);
  const [newReview, setNewReview] = useState({
    userName: '',
    rating: 5,
    comment: '',
  });

  const handleAddToCart = () => {
    onAddToCart(book.id, quantity);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.userName.trim() || !newReview.comment.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    const review: Review = {
      id: reviews.length + 1,
      userName: newReview.userName,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toISOString().split('T')[0],
    };

    setReviews([review, ...reviews]);
    setNewReview({ userName: '', rating: 5, comment: '' });
    toast.success('Review submitted successfully!');
  };

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length).toFixed(2)
    : '0.00';

  const getRatingCount = (rating: number) => {
    return reviews.filter(review => review.rating === rating).length;
  };

  const handleIncrement = () => {
    setQuantity(prev => prev + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Book Detail Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Book Image */}
          <div>
            <img
              src={book.image}
              alt={book.title}
              className="w-full max-w-sm mx-auto rounded-lg shadow-lg"
            />
          </div>

          {/* Book Info */}
          <div>
            <h1 className="text-emerald-800 mb-4">{book.title}</h1>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-emerald-800">₹ {book.price}</span>
            </div>
            <p className="text-gray-600 text-sm mb-6">Only 3 item(s) left in stock</p>

            {/* Quantity Selector */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border border-gray-300 rounded">
                <button
                  onClick={handleDecrement}
                  className="p-2 hover:bg-gray-100 transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-6 py-2 border-x border-gray-300">{quantity}</span>
                <button
                  onClick={handleIncrement}
                  className="p-2 hover:bg-gray-100 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <Button 
                onClick={handleAddToCart}
                className="bg-red-600 hover:bg-red-700 hover:scale-105 transition-all px-8"
              >
                ADD TO CART
              </Button>
            </div>

            <Button 
              onClick={onBuyNow}
              className="w-full bg-emerald-800 hover:bg-emerald-900 hover:scale-105 transition-all mb-6"
            >
              BUY NOW
            </Button>

            {/* Share Buttons */}
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-2 text-gray-700">
                <Share2 className="w-4 h-4" />
                Share
              </span>
              <button className="hover:text-emerald-600 transition-colors">
                <Twitter className="w-5 h-5" />
              </button>
              <button className="hover:text-emerald-600 transition-colors">
                <Facebook className="w-5 h-5" />
              </button>
              <button className="hover:text-emerald-600 transition-colors">
                <MessageCircle className="w-5 h-5" />
              </button>
              <button className="hover:text-emerald-600 transition-colors">
                <Linkedin className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mb-12">
          <h2 className="text-emerald-800 mb-4">Description</h2>
          <p className="text-gray-700 leading-relaxed">
            {book.description || 'உலகின் முதன்மையான ஒரு அதிசிய செய்தி அன்பு! அன்பே வாழ்க்கையின் முழுமையான இருக்கிறது. தாவீனியின் நிகழ்கள் நூல் இரு நிகழ்ச்சிகளையும் முழுமையாக கொண்டுள்ளது. முதலாம் நிகழ்வு சற்று புதிரானது, அதில் பல வித்தியாசமான செய்திகள் உள்ளன. இரண்டாம் நிகழ்வு முதலாம் நிகழ்வை விட தெளிவானது மற்றும் புரிந்து கொள்ள எளிதானது. இந்த நூல் வாசகர்களுக்கு ஒரு புதிய அனுபவத்தை வழங்கும் என்று நம்புகிறோம்.'}
          </p>
        </div>

        {/* Additional Information */}
        <div className="mb-12">
          <h2 className="text-emerald-800 mb-4">Additional Information</h2>
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full">
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Weight</td>
                  <td className="py-3 px-4">{book.weight || '0.2 g'}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Dimensions</td>
                  <td className="py-3 px-4">{book.dimensions || '8.3 × 5.3 × 0.6 cm'}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Author</td>
                  <td className="py-3 px-4">{book.author || 'மருதமுத்து செல்வராஜ் செல்வம், முன்னுரை: சித்திக்'}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Pages</td>
                  <td className="py-3 px-4">{book.pages || 120}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 bg-gray-50">Format</td>
                  <td className="py-3 px-4">{book.format || 'Paperback'}</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 bg-gray-50">ISBN</td>
                  <td className="py-3 px-4">{book.isbn || '9789384303181'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Reviews */}
        <div className="mb-12">
          <h2 className="text-emerald-800 mb-6">Review(s)</h2>
          
          <div className="flex items-start gap-12 mb-8">
            <div className="text-center">
              <div className="mb-2">{averageRating}</div>
              <div className="flex gap-1 text-yellow-500">
                {[1, 2, 3, 4, 5].map(star => (
                  <span key={star}>★</span>
                ))}
              </div>
              <div className="text-gray-600 text-sm mt-2">{reviews.length} Review(s)</div>
            </div>

            <div className="flex-1 space-y-2">
              {[5, 4, 3, 2, 1].map(rating => {
                const count = getRatingCount(rating);
                const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                return (
                  <div key={rating} className="flex items-center gap-3">
                    <span className="w-4">{rating}</span>
                    <span className="text-yellow-500">★</span>
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-yellow-500 h-2 rounded-full transition-all" 
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                    <span className="w-8 text-right text-gray-600">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Add Review Form */}
        <div className="mb-12">
          <h3 className="text-emerald-800 mb-6">Write a Review</h3>
          <form onSubmit={handleSubmitReview} className="bg-gray-50 p-6 rounded-lg border-2 border-emerald-700">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="userName" className="block mb-2 text-gray-700">Your Name</label>
                <Input
                  id="userName"
                  type="text"
                  placeholder="Enter your name"
                  value={newReview.userName}
                  onChange={(e) => setNewReview({ ...newReview, userName: e.target.value })}
                  required
                  className="border-emerald-700"
                />
              </div>
              <div>
                <label htmlFor="rating" className="block mb-2 text-gray-700">Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setNewReview({ ...newReview, rating: star })}
                      className="text-3xl hover:scale-125 transition-transform"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= newReview.rating
                            ? 'fill-yellow-500 text-yellow-500'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="mb-6">
              <label htmlFor="comment" className="block mb-2 text-gray-700">Your Review</label>
              <Textarea
                id="comment"
                placeholder="Share your thoughts about this book..."
                value={newReview.comment}
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                required
                rows={4}
                className="border-emerald-700"
              />
            </div>
            <Button 
              type="submit"
              className="bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all"
            >
              <Send className="w-4 h-4 mr-2" />
              Submit Review
            </Button>
          </form>
        </div>

        {/* Display Reviews */}
        <div className="mb-12">
          <h3 className="text-emerald-800 mb-6">Customer Reviews</h3>
          <div className="space-y-6">
            {reviews.map((review, index) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-6 rounded-lg border-2 border-gray-200 hover:border-emerald-600 transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="text-gray-900">{review.userName}</h4>
                    <div className="flex gap-1 mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= review.rating
                              ? 'fill-yellow-500 text-yellow-500'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <span className="text-sm text-gray-500">{review.date}</span>
                </div>
                <p className="text-gray-700">{review.comment}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Related Books */}
        <div>
          <h2 className="text-emerald-800 text-center mb-8">Related Books</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedBooks.map((relatedBook) => (
              <BookCard
                key={relatedBook.id}
                title={relatedBook.title}
                price={relatedBook.price}
                image={relatedBook.image}
                onSale={relatedBook.onSale}
                onClick={() => onBookClick(relatedBook.id)}
                onAddToCart={(e) => {
                  e.stopPropagation();
                  onAddRelatedToCart(relatedBook.id);
                }}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
