import { useEffect } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

interface PaymentSuccessProps {
  onComplete: () => void;
  totalAmount: number;
}

export function PaymentSuccess({ onComplete, totalAmount }: PaymentSuccessProps) {
  useEffect(() => {
    // Auto-redirect to tracking page after 3 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-white flex items-center justify-center px-4">
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, type: "spring", stiffness: 200 }}
        className="text-center"
      >
        {/* Success Icon with Animation */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-block mb-6"
        >
          <div className="relative">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.2, 1] }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <CheckCircle2 className="w-32 h-32 text-emerald-600" strokeWidth={1.5} />
            </motion.div>
            
            {/* Animated Circle */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 2, opacity: 0 }}
              transition={{ delay: 0.4, duration: 1, ease: "easeOut" }}
              className="absolute inset-0 border-4 border-emerald-600 rounded-full"
            />
          </div>
        </motion.div>

        {/* Success Message */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <h1 className="text-emerald-800 mb-4">Payment Successful!</h1>
          <p className="text-gray-600 text-xl mb-2">Thank you for your purchase</p>
          <p className="text-gray-500 mb-6">
            Amount Paid: <span className="text-emerald-700">₹ {totalAmount}</span>
          </p>
        </motion.div>

        {/* Confetti Elements */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ y: 0, x: 0, opacity: 1 }}
            animate={{
              y: [0, -100, 200],
              x: [(i % 2 === 0 ? -1 : 1) * (50 + i * 20)],
              opacity: [1, 1, 0],
              rotate: [0, 360],
            }}
            transition={{
              delay: 0.3 + i * 0.05,
              duration: 2,
              ease: "easeOut"
            }}
            className="absolute top-1/2 left-1/2 w-3 h-3 rounded-full"
            style={{
              backgroundColor: [
                '#10b981',
                '#ef4444',
                '#f59e0b',
                '#3b82f6',
                '#8b5cf6',
                '#ec4899'
              ][i % 6]
            }}
          />
        ))}

        {/* Loading Animation */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-8"
        >
          <p className="text-gray-500 text-sm mb-3">Redirecting to tracking page...</p>
          <div className="flex justify-center gap-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{ y: [0, -10, 0] }}
                transition={{
                  delay: i * 0.15,
                  duration: 0.6,
                  repeat: Infinity,
                  repeatDelay: 0.3
                }}
                className="w-2 h-2 bg-emerald-600 rounded-full"
              />
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
