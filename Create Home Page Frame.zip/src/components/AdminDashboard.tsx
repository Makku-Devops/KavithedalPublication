import { useState, useEffect } from 'react';
import { LogOut, Plus, Edit, Trash2, Star, Tag, Book, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { AddBookForm } from './AddBookForm';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';
import { motion } from 'motion/react';

interface Book {
  id: number;
  title: string;
  price: number;
  image: string;
  onSale: boolean;
  offer?: string;
  category: string;
  isFeatured?: boolean;
  offerPercentage?: number;
  description?: string;
  author?: string;
  isbn?: string;
  pages?: number;
  format?: string;
}

interface AdminDashboardProps {
  onLogout: () => void;
  books: Book[];
  onAddBook: (book: Book) => void;
  onUpdateBook: (book: Book) => void;
  onDeleteBook: (bookId: number) => void;
}

export function AdminDashboard({ onLogout, books, onAddBook, onUpdateBook, onDeleteBook }: AdminDashboardProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [stats, setStats] = useState({
    totalBooks: 0,
    featuredBooks: 0,
    booksOnOffer: 0,
  });

  useEffect(() => {
    setStats({
      totalBooks: books.length,
      featuredBooks: books.filter(b => b.isFeatured).length,
      booksOnOffer: books.filter(b => b.offerPercentage && b.offerPercentage > 0).length,
    });
  }, [books]);

  const handleLogout = () => {
    localStorage.removeItem('adminAuth');
    toast.success('Logged out successfully');
    onLogout();
  };

  const handleToggleFeatured = (book: Book) => {
    const updatedBook = { ...book, isFeatured: !book.isFeatured };
    onUpdateBook(updatedBook);
    toast.success(`Book ${updatedBook.isFeatured ? 'marked as featured' : 'removed from featured'}`);
  };

  const handleDelete = (bookId: number) => {
    if (confirm('Are you sure you want to delete this book?')) {
      onDeleteBook(bookId);
      toast.success('Book deleted successfully');
    }
  };

  const handleSaveBook = (book: Book) => {
    if (editingBook) {
      onUpdateBook(book);
      toast.success('Book updated successfully');
      setEditingBook(null);
    } else {
      onAddBook(book);
      toast.success('Book added successfully');
    }
    setShowAddForm(false);
  };

  const calculateDiscountedPrice = (price: number, offerPercentage?: number) => {
    if (!offerPercentage || offerPercentage === 0) return price;
    return Math.round(price - (price * offerPercentage / 100));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-emerald-800 text-white shadow-lg sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-white">Admin Dashboard</h1>
              <p className="text-emerald-200 text-sm mt-1">Manage your bookstore</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-emerald-800 hover:scale-105 transition-all"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-6 rounded-lg shadow-md border-l-4 border-emerald-600"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Books</p>
                <p className="mt-2">{stats.totalBooks}</p>
              </div>
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center">
                <Book className="w-6 h-6 text-emerald-700" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white p-6 rounded-lg shadow-md border-l-4 border-yellow-600"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Featured Books</p>
                <p className="mt-2">{stats.featuredBooks}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Star className="w-6 h-6 text-yellow-700" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-600"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Books on Offer</p>
                <p className="mt-2">{stats.booksOnOffer}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Tag className="w-6 h-6 text-red-700" />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Add Book Button */}
        <div className="mb-6">
          <Button
            onClick={() => {
              setShowAddForm(true);
              setEditingBook(null);
            }}
            className="bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Book
          </Button>
        </div>

        {/* Add/Edit Book Form */}
        {showAddForm && (
          <div className="mb-8">
            <AddBookForm
              book={editingBook}
              onSave={handleSaveBook}
              onCancel={() => {
                setShowAddForm(false);
                setEditingBook(null);
              }}
            />
          </div>
        )}

        {/* Books List */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b">
            <h2 className="text-emerald-800">All Books</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs text-gray-600 uppercase tracking-wider">
                    Book
                  </th>
                  <th className="px-6 py-3 text-left text-xs text-gray-600 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="px-6 py-3 text-left text-xs text-gray-600 uppercase tracking-wider">
                    Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs text-gray-600 uppercase tracking-wider">
                    Offer
                  </th>
                  <th className="px-6 py-3 text-left text-xs text-gray-600 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs text-gray-600 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {books.map((book) => (
                  <tr key={book.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={book.image}
                          alt={book.title}
                          className="w-12 h-16 object-cover rounded"
                        />
                        <div>
                          <p className="text-gray-900">{book.title}</p>
                          {book.author && (
                            <p className="text-sm text-gray-500">{book.author}</p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="capitalize">
                        {book.category}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        {book.offerPercentage && book.offerPercentage > 0 ? (
                          <>
                            <p className="text-emerald-700">
                              ₹{calculateDiscountedPrice(book.price, book.offerPercentage)}
                            </p>
                            <p className="text-sm text-gray-500 line-through">₹{book.price}</p>
                          </>
                        ) : (
                          <p className="text-gray-900">₹{book.price}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {book.offerPercentage && book.offerPercentage > 0 ? (
                        <Badge className="bg-red-600">
                          {book.offerPercentage}% OFF
                        </Badge>
                      ) : (
                        <span className="text-gray-400">No offer</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        {book.isFeatured && (
                          <Badge className="bg-yellow-600">
                            <Star className="w-3 h-3 mr-1" />
                            Featured
                          </Badge>
                        )}
                        {book.onSale && (
                          <Badge className="bg-emerald-600">Sale</Badge>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleToggleFeatured(book)}
                          size="sm"
                          variant="outline"
                          className={`hover:scale-105 transition-all ${
                            book.isFeatured ? 'bg-yellow-50 border-yellow-600 text-yellow-700' : ''
                          }`}
                        >
                          <Star className={`w-4 h-4 ${book.isFeatured ? 'fill-current' : ''}`} />
                        </Button>
                        <Button
                          onClick={() => {
                            setEditingBook(book);
                            setShowAddForm(true);
                          }}
                          size="sm"
                          variant="outline"
                          className="hover:bg-blue-50 hover:scale-105 transition-all"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => handleDelete(book.id)}
                          size="sm"
                          variant="outline"
                          className="hover:bg-red-50 hover:text-red-700 hover:scale-105 transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
