import { motion, AnimatePresence } from 'motion/react';
import { X, Package, Tag, Truck, Bell } from 'lucide-react';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Notification {
  id: number;
  title: string;
  message: string;
  time: string;
  type: 'order' | 'offer' | 'delivery' | 'general';
  unread: boolean;
}

const notifications: Notification[] = [
  {
    id: 1,
    title: 'New Offer Available!',
    message: 'Get 20% off on all Tamil literature books this weekend',
    time: '2 hours ago',
    type: 'offer',
    unread: true,
  },
  {
    id: 2,
    title: 'Order Shipped',
    message: 'Your order #12345 has been shipped and will arrive soon',
    time: '1 day ago',
    type: 'delivery',
    unread: true,
  },
  {
    id: 3,
    title: 'New Arrivals',
    message: 'Check out our latest collection of poetry books',
    time: '2 days ago',
    type: 'general',
    unread: false,
  },
];

const getIcon = (type: string) => {
  switch (type) {
    case 'order':
      return <Package className="w-5 h-5" />;
    case 'offer':
      return <Tag className="w-5 h-5" />;
    case 'delivery':
      return <Truck className="w-5 h-5" />;
    default:
      return <Bell className="w-5 h-5" />;
  }
};

const getIconColor = (type: string) => {
  switch (type) {
    case 'order':
      return 'bg-blue-100 text-blue-600';
    case 'offer':
      return 'bg-red-100 text-red-600';
    case 'delivery':
      return 'bg-emerald-100 text-emerald-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
};

export function NotificationPanel({ isOpen, onClose }: NotificationPanelProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-40"
          />

          {/* Notification Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl z-50 overflow-y-auto"
          >
            {/* Header */}
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <div>
                <h2 className="text-emerald-800">Notifications</h2>
                <p className="text-sm text-gray-500 mt-1">
                  You have {notifications.filter(n => n.unread).length} unread notifications
                </p>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            {/* Notifications List */}
            <div className="p-4 space-y-3">
              {notifications.map((notification, index) => (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 rounded-lg border-2 transition-all cursor-pointer hover:shadow-md ${
                    notification.unread
                      ? 'border-emerald-600 bg-emerald-50'
                      : 'border-gray-200 bg-white'
                  }`}
                >
                  <div className="flex gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${getIconColor(notification.type)}`}>
                      {getIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className={`${notification.unread ? 'text-emerald-800' : 'text-gray-900'}`}>
                          {notification.title}
                        </h3>
                        {notification.unread && (
                          <div className="w-2 h-2 rounded-full bg-red-600 flex-shrink-0 mt-2" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                      <p className="text-xs text-gray-500">{notification.time}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4">
              <button className="w-full py-2 text-emerald-700 hover:text-emerald-800 transition-colors">
                Mark all as read
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
