import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { useState } from 'react';
import { toast } from 'sonner@2.0.3';

export function ContactUs() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Message sent successfully! We will get back to you soon.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <section className="max-w-7xl mx-auto px-6 py-12">
      <h2 className="text-emerald-800 text-center mb-12">Contact Us</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Contact Information */}
        <div className="space-y-8">
          <div>
            <h3 className="text-emerald-800 mb-6">Get in Touch</h3>
            <p className="text-gray-600 mb-8">
              Have questions about our books or services? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h4 className="mb-1">Address</h4>
                <p className="text-gray-600">
                  123 Book Street, Chennai<br />
                  Tamil Nadu 600001, India
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h4 className="mb-1">Phone</h4>
                <p className="text-gray-600">+91 98765 43210</p>
                <p className="text-gray-600">+91 98765 43211</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Mail className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h4 className="mb-1">Email</h4>
                <p className="text-gray-600">info@kavithalaibooks.com</p>
                <p className="text-gray-600">support@kavithalaibooks.com</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Clock className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h4 className="mb-1">Business Hours</h4>
                <p className="text-gray-600">Monday - Saturday: 9:00 AM - 7:00 PM</p>
                <p className="text-gray-600">Sunday: 10:00 AM - 5:00 PM</p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-gray-50 p-8 rounded-lg border-2 border-emerald-700">
          <h3 className="text-emerald-800 mb-6">Send us a Message</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block mb-2 text-gray-700">Your Name</label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="border-emerald-700"
              />
            </div>

            <div>
              <label htmlFor="email" className="block mb-2 text-gray-700">Email Address</label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="border-emerald-700"
              />
            </div>

            <div>
              <label htmlFor="subject" className="block mb-2 text-gray-700">Subject</label>
              <Input
                id="subject"
                type="text"
                placeholder="What is this about?"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                required
                className="border-emerald-700"
              />
            </div>

            <div>
              <label htmlFor="message" className="block mb-2 text-gray-700">Message</label>
              <Textarea
                id="message"
                placeholder="Write your message here..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                required
                rows={5}
                className="border-emerald-700"
              />
            </div>

            <Button 
              type="submit"
              className="w-full bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all"
            >
              <Send className="w-4 h-4 mr-2" />
              Send Message
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}
