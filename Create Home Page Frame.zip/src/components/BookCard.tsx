import { ImageWithFallback } from './figma/ImageWithFallback';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ShoppingCart, Heart, Star } from 'lucide-react';
import { useState } from 'react';

interface BookCardProps {
  title: string;
  price: number;
  image: string;
  onSale?: boolean;
  offer?: string;
  offerPercentage?: number;
  isFeatured?: boolean;
  onClick?: () => void;
  onAddToCart?: (e: React.MouseEvent) => void;
}

export function BookCard({ 
  title, 
  price, 
  image, 
  onSale = false, 
  offer, 
  offerPercentage,
  isFeatured = false,
  onClick, 
  onAddToCart 
}: BookCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const calculateDiscountedPrice = () => {
    if (!offerPercentage || offerPercentage === 0) return price;
    return Math.round(price - (price * offerPercentage / 100));
  };

  const discountedPrice = calculateDiscountedPrice();
  const hasDiscount = offerPercentage && offerPercentage > 0;

  return (
    <div className="flex flex-col gap-3 group">
      <div className="relative aspect-[2/3] overflow-hidden rounded-lg shadow-md group-hover:shadow-xl transition-shadow cursor-pointer" onClick={onClick}>
        {/* Offer Badge - Left Side */}
        {offer && (
          <Badge className="absolute top-2 left-2 bg-red-600 hover:bg-red-600 z-10">
            {offer}
          </Badge>
        )}
        
        {/* Sale Badge - Left Side (below offer if both exist) */}
        {onSale && !offer && (
          <Badge className="absolute top-2 left-2 bg-emerald-600 hover:bg-emerald-600 z-10">
            Sale
          </Badge>
        )}
        
        {/* Featured Star Badge - Top Left (below other badges) */}
        {isFeatured && (
          <Badge className="absolute top-14 left-2 bg-yellow-600 hover:bg-yellow-600 z-10 flex items-center gap-1">
            <Star className="w-3 h-3 fill-white" />
            Featured
          </Badge>
        )}
        
        {/* Favorite Icon - Right Side */}
        <button
          onClick={handleFavoriteClick}
          className="absolute top-2 right-2 z-10 w-8 h-8 rounded-full bg-white/90 hover:bg-white flex items-center justify-center transition-all shadow-md"
        >
          <Heart 
            className={`w-5 h-5 transition-colors ${
              isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'
            }`}
          />
        </button>
        
        <ImageWithFallback
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex flex-col gap-2">
        <div className="cursor-pointer" onClick={onClick}>
          <h3 className="text-gray-900 line-clamp-2">{title}</h3>
          <div className="flex items-center gap-2 mt-1">
            {hasDiscount ? (
              <>
                <p className="text-emerald-700">₹ {discountedPrice}</p>
                <p className="text-sm text-gray-500 line-through">₹ {price}</p>
              </>
            ) : (
              <p className="text-gray-900">₹ {price}</p>
            )}
          </div>
          {hasDiscount && (
            <p className="text-xs text-green-600 mt-1">
              Save ₹{price - discountedPrice}
            </p>
          )}
        </div>
        {onAddToCart && (
          <Button
            onClick={onAddToCart}
            size="sm"
            className="bg-emerald-700 hover:bg-emerald-800 hover:scale-105 transition-all w-full"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        )}
      </div>
    </div>
  );
}
