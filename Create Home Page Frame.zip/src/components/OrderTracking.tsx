import { motion } from 'motion/react';
import { Package, Truck, CheckCircle2, MapPin, Calendar, User, Phone, Mail } from 'lucide-react';
import { Button } from './ui/button';

interface OrderTrackingProps {
  book: {
    id: number;
    title: string;
    price: number;
    image: string;
  };
  quantity: number;
  totalAmount: number;
  onBackToHome: () => void;
}

export function OrderTracking({ book, quantity, totalAmount, onBackToHome }: OrderTrackingProps) {
  // Generate order details
  const orderNumber = `ORD${Math.floor(100000 + Math.random() * 900000)}`;
  const orderDate = new Date().toLocaleDateString('en-IN', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  const estimatedDelivery = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const trackingSteps = [
    {
      id: 1,
      title: 'Order Placed',
      description: 'Your order has been received',
      date: orderDate,
      time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      icon: CheckCircle2,
      completed: true,
      active: false,
    },
    {
      id: 2,
      title: 'Processing',
      description: 'Your order is being prepared',
      date: orderDate,
      time: 'In Progress',
      icon: Package,
      completed: true,
      active: true,
    },
    {
      id: 3,
      title: 'Shipped',
      description: 'Your package is on its way',
      date: 'Pending',
      time: '',
      icon: Truck,
      completed: false,
      active: false,
    },
    {
      id: 4,
      title: 'Delivered',
      description: 'Package delivered successfully',
      date: estimatedDelivery,
      time: 'Expected',
      icon: MapPin,
      completed: false,
      active: false,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="bg-emerald-700 text-white rounded-lg p-6 mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="mb-2">Order Confirmed!</h1>
              <p className="text-emerald-100">Order #{orderNumber}</p>
            </div>
            <CheckCircle2 className="w-16 h-16 text-emerald-200" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>Order Date: {orderDate}</span>
            </div>
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              <span>Items: {quantity}</span>
            </div>
            <div className="flex items-center gap-2">
              <span>Total: ₹ {totalAmount}</span>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Tracking Timeline */}
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="bg-white rounded-lg border-2 border-emerald-700 p-6"
            >
              <h2 className="text-emerald-700 mb-6">Order Tracking</h2>
              
              <div className="relative">
                {trackingSteps.map((step, index) => (
                  <motion.div
                    key={step.id}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                    className="relative flex gap-4 pb-8 last:pb-0"
                  >
                    {/* Connector Line */}
                    {index < trackingSteps.length - 1 && (
                      <div className="absolute left-6 top-12 w-0.5 h-full bg-gray-200">
                        <motion.div
                          initial={{ height: 0 }}
                          animate={{ height: step.completed ? '100%' : '0%' }}
                          transition={{ delay: 0.5 + index * 0.2, duration: 0.5 }}
                          className="w-full bg-emerald-600"
                        />
                      </div>
                    )}

                    {/* Icon */}
                    <div className={`relative z-10 flex items-center justify-center w-12 h-12 rounded-full border-2 ${
                      step.completed 
                        ? 'bg-emerald-600 border-emerald-600' 
                        : step.active
                        ? 'bg-white border-emerald-600'
                        : 'bg-white border-gray-300'
                    }`}>
                      <step.icon className={`w-6 h-6 ${
                        step.completed 
                          ? 'text-white' 
                          : step.active
                          ? 'text-emerald-600'
                          : 'text-gray-400'
                      }`} />
                    </div>

                    {/* Content */}
                    <div className="flex-1 pt-1">
                      <h3 className={`mb-1 ${
                        step.completed || step.active ? 'text-gray-900' : 'text-gray-500'
                      }`}>
                        {step.title}
                      </h3>
                      <p className="text-gray-600 text-sm mb-1">{step.description}</p>
                      <p className="text-gray-500 text-xs">
                        {step.date} {step.time && `• ${step.time}`}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Order Items */}
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="bg-white rounded-lg border-2 border-emerald-700 p-6"
            >
              <h2 className="text-emerald-700 mb-6">Order Items</h2>
              
              <div className="flex gap-4">
                <img
                  src={book.image}
                  alt={book.title}
                  className="w-24 h-32 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="mb-2">{book.title}</h3>
                  <p className="text-gray-600 mb-2">Quantity: {quantity}</p>
                  <p className="text-emerald-700">₹ {book.price} × {quantity} = ₹ {book.price * quantity}</p>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="space-y-2">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal</span>
                    <span>₹ {book.price * quantity}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Shipping</span>
                    <span>₹ {totalAmount - book.price * quantity}</span>
                  </div>
                  <div className="flex justify-between border-t pt-2 mt-2">
                    <span>Total</span>
                    <span className="text-red-600">₹ {totalAmount}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Delivery Information */}
            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="bg-white rounded-lg border-2 border-emerald-700 p-6"
            >
              <h3 className="text-emerald-700 mb-4">Delivery Address</h3>
              <div className="space-y-3 text-sm text-gray-700">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5 text-emerald-600" />
                  <div>
                    <p>123 Main Street</p>
                    <p>Chennai, Tamil Nadu</p>
                    <p>600001</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Contact Information */}
            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="bg-white rounded-lg border-2 border-emerald-700 p-6"
            >
              <h3 className="text-emerald-700 mb-4">Contact Information</h3>
              <div className="space-y-3 text-sm text-gray-700">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-emerald-600" />
                  <span>Customer Name</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-600" />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-emerald-600" />
                  <span>customer@example.com</span>
                </div>
              </div>
            </motion.div>

            {/* Expected Delivery */}
            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="bg-emerald-50 rounded-lg border border-emerald-200 p-6"
            >
              <div className="flex items-center gap-3 mb-2">
                <Truck className="w-5 h-5 text-emerald-700" />
                <h3 className="text-emerald-700">Expected Delivery</h3>
              </div>
              <p className="text-emerald-900">{estimatedDelivery}</p>
              <p className="text-emerald-600 text-sm mt-1">Estimated 3-5 business days</p>
            </motion.div>

            <Button 
              onClick={onBackToHome}
              className="w-full bg-emerald-700 hover:bg-emerald-800"
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
