import { useState } from 'react';
import { Search, ShoppingCart, Bell } from 'lucide-react';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface HeaderProps {
  cartItemCount: number;
  onCartClick: () => void;
  onNotificationClick: () => void;
  onSearch: (query: string) => void;
}

export function Header({ cartItemCount, onCartClick, onNotificationClick, onSearch }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = () => {
    if (searchQuery.trim()) {
      onSearch(searchQuery.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <header className="bg-emerald-800 text-white py-4 px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Logo - Left Side */}
        <div className="flex items-center">
          <h1 className="whitespace-nowrap">Kavithalai Books</h1>
        </div>
        
        {/* Search Bar - Center */}
        <div className="flex items-center gap-2 flex-1 max-w-2xl">
          <Input
            type="search"
            placeholder="Search for books..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            className="bg-white text-gray-900 border-0"
          />
          <Button 
            onClick={handleSearch}
            className="bg-red-600 hover:bg-red-700 hover:scale-105 transition-all px-6"
          >
            Search
          </Button>
        </div>
        
        {/* Icons - Right Side */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onCartClick}
            className="relative hover:opacity-80 hover:scale-110 transition-all"
          >
            <ShoppingCart className="w-6 h-6" />
            {cartItemCount > 0 && (
              <Badge className="absolute -top-2 -right-2 bg-red-600 hover:bg-red-600 w-5 h-5 rounded-full flex items-center justify-center p-0">
                {cartItemCount}
              </Badge>
            )}
          </button>
          <button 
            onClick={onNotificationClick}
            className="relative hover:opacity-80 hover:scale-110 transition-all"
          >
            <Bell className="w-6 h-6" />
            <Badge className="absolute -top-2 -right-2 bg-red-600 hover:bg-red-600 w-5 h-5 rounded-full flex items-center justify-center p-0">
              3
            </Badge>
          </button>
        </div>
      </div>
    </header>
  );
}
