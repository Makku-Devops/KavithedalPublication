import { MessageCircle } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

export function Navigation({ activeSection, onNavigate }: NavigationProps) {
  return (
    <nav className="bg-white border-b shadow-sm sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-center py-4">
          <ul className="flex items-center gap-16">
            <li>
              <button 
                onClick={() => onNavigate('home')}
                className={`hover:text-emerald-800 transition-all hover:scale-105 ${
                  activeSection === 'home' ? 'text-emerald-800' : 'text-gray-900'
                }`}
              >
                Home
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('books')}
                className={`hover:text-emerald-800 transition-all hover:scale-105 ${
                  activeSection === 'books' ? 'text-emerald-800' : 'text-gray-900'
                }`}
              >
                Books
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('contact')}
                className={`hover:text-emerald-800 transition-all hover:scale-105 ${
                  activeSection === 'contact' ? 'text-emerald-800' : 'text-gray-900'
                }`}
              >
                Contact us
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('category')}
                className={`hover:text-emerald-800 transition-all hover:scale-105 ${
                  activeSection === 'category' ? 'text-emerald-800' : 'text-gray-900'
                }`}
              >
                Category
              </button>
            </li>
            <li>
              <a 
                href="https://wa.me/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-emerald-600 hover:text-emerald-900 transition-all hover:scale-105 flex items-center gap-2"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>WhatsApp</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
