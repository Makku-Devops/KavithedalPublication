import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Heart, Sparkles, Users, Globe, BookMarked } from 'lucide-react';
import { BookCard } from './BookCard';

const categories = [
  { id: 'all', name: 'All Books', color: 'bg-gray-600 hover:bg-gray-700', icon: BookOpen },
  { id: 'fiction', name: 'Fiction', color: 'bg-purple-600 hover:bg-purple-700', icon: Sparkles },
  { id: 'poetry', name: 'Poetry', color: 'bg-pink-600 hover:bg-pink-700', icon: Heart },
  { id: 'literature', name: 'Literature', color: 'bg-blue-600 hover:bg-blue-700', icon: BookMarked },
  { id: 'biography', name: 'Biography', color: 'bg-orange-600 hover:bg-orange-700', icon: Users },
  { id: 'history', name: 'History', color: 'bg-emerald-600 hover:bg-emerald-700', icon: Globe },
];

interface Book {
  id: number;
  title: string;
  price: number;
  image: string;
  onSale: boolean;
  offer?: string;
  category: string;
}

const categoryBooks: Book[] = [
  {
    id: 1,
    title: 'காலியாகாரின் முகங்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1664793937878-4b663ff216f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjByZWR8ZW58MXx8fHwxNzYxMzczMjU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: false,
    offer: '15% OFF',
    category: 'fiction',
  },
  {
    id: 2,
    title: 'வெண்முரசு சாரல்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1674154642704-0a4f0bdcb676?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBkYXJrfGVufDF8fHx8MTc2MTM3MzI1OXww&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: false,
    category: 'history',
  },
  {
    id: 3,
    title: 'படப்புச்சி விஷயங்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1705837861201-dd000d929a31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBncmVlbnxlbnwxfHx8fDE3NjEzNzMyNTl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: true,
    offer: '20% OFF',
    category: 'fiction',
  },
  {
    id: 5,
    title: 'புதிய காலத்து கவிதைகள்',
    price: 350,
    image: 'https://images.unsplash.com/photo-1614708403338-cdf1914fb117?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBvcmFuZ2V8ZW58MXx8fHwxNzYxMzA0NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: true,
    offer: '25% OFF',
    category: 'poetry',
  },
  {
    id: 6,
    title: 'இலக்கியத்தின் ஒளி',
    price: 450,
    image: 'https://images.unsplash.com/photo-1622481168506-3cce81c393c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjB5ZWxsb3d8ZW58MXx8fHwxNzYxMzczNjM5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: false,
    offer: 'NEW',
    category: 'literature',
  },
  {
    id: 7,
    title: 'கனவுகளின் பாதை',
    price: 280,
    image: 'https://images.unsplash.com/photo-1643913398973-f8e24bf6d1c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBwdXJwbGV8ZW58MXx8fHwxNzYxMzczNjM5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: false,
    category: 'poetry',
  },
  {
    id: 9,
    title: 'தாலியகாரின் நிகழ்வுகள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1744693660970-3517f524fb28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBjb2xvcmZ1bHxlbnwxfHx8fDE3NjEzNzM1Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: false,
    offer: '10% OFF',
    category: 'biography',
  },
  {
    id: 10,
    title: 'மேகங்கள் கேட்கும் குரல்கள்',
    price: 600,
    image: 'https://images.unsplash.com/photo-1709744599674-6a4e37a65ca9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjB2aW50YWdlfGVufDF8fHx8MTc2MTM2NTYyMXww&ixlib=rb-4.1.0&q=80&w=1080',
    onSale: false,
    category: 'history',
  },
];

interface CategorySectionProps {
  onBookClick: (bookId: number) => void;
  onAddToCart: (bookId: number) => void;
}

export function CategorySection({ onBookClick, onAddToCart }: CategorySectionProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredBooks = selectedCategory === 'all' 
    ? categoryBooks 
    : categoryBooks.filter(book => book.category === selectedCategory);

  return (
    <section className="max-w-7xl mx-auto px-6 py-12">
      <h2 className="text-emerald-800 text-center mb-8">Browse by Category</h2>
      
      {/* Category Buttons */}
      <div className="flex flex-wrap justify-center gap-4 mb-12">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <motion.button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`${category.color} ${
                selectedCategory === category.id ? 'ring-4 ring-offset-2 ring-gray-400' : ''
              } text-white px-6 py-3 rounded-full transition-all shadow-md hover:shadow-lg flex items-center gap-2`}
            >
              <Icon className="w-5 h-5" />
              <span>{category.name}</span>
            </motion.button>
          );
        })}
      </div>

      {/* Books Grid */}
      <motion.div 
        key={selectedCategory}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-6"
      >
        {filteredBooks.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            price={book.price}
            image={book.image}
            onSale={book.onSale}
            offer={book.offer}
            offerPercentage={book.offerPercentage}
            isFeatured={book.isFeatured}
            onClick={() => onBookClick(book.id)}
            onAddToCart={(e) => {
              e.stopPropagation();
              onAddToCart(book.id);
            }}
          />
        ))}
      </motion.div>

      {filteredBooks.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No books found in this category.</p>
        </div>
      )}
    </section>
  );
}
