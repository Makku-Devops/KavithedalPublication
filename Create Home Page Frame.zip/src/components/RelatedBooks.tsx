import { BookCard } from './BookCard';

export const relatedBooks = [
  {
    id: 9,
    title: 'தாலியகாரின் நிகழ்வுகள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1744693660970-3517f524fb28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBjb2xvcmZ1bHxlbnwxfHx8fDE3NjEzNzM1Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
    offer: '10% OFF',
  },
  {
    id: 10,
    title: 'மேகங்கள் கேட்கும் குரல்கள்',
    price: 600,
    image: 'https://images.unsplash.com/photo-1709744599674-6a4e37a65ca9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjB2aW50YWdlfGVufDF8fHx8MTc2MTM2NTYyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
  },
  {
    id: 11,
    title: 'பழமையின் புத்தகம்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1739521949473-a703e0536ddf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBtb2Rlcm58ZW58MXx8fHwxNzYxMzQwNzc4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: true,
    offer: '30% OFF',
  },
  {
    id: 12,
    title: 'நீலவானம் சித்திரக்காரர்கள்',
    price: 200,
    image: 'https://images.unsplash.com/photo-1544736779-08492534e887?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBibHVlfGVufDF8fHx8MTc2MTM3MzU4MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    onSale: false,
  },
];

interface RelatedBooksProps {
  onBookClick: (bookId: number) => void;
  onAddToCart: (bookId: number) => void;
}

export function RelatedBooks({ onBookClick, onAddToCart }: RelatedBooksProps) {
  return (
    <section className="max-w-7xl mx-auto px-6 py-12">
      <h2 className="text-emerald-800 text-center mb-8">Related Books</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {relatedBooks.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            price={book.price}
            image={book.image}
            onSale={book.onSale}
            offer={book.offer}
            offerPercentage={book.offerPercentage}
            isFeatured={book.isFeatured}
            onClick={() => onBookClick(book.id)}
            onAddToCart={(e) => {
              e.stopPropagation();
              onAddToCart(book.id);
            }}
          />
        ))}
      </div>
    </section>
  );
}
