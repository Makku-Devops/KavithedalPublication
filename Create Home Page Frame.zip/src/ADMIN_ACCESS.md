# Admin Panel Access Instructions

## How to Access the Admin Panel

The admin panel is hidden from regular customers and can be accessed in the following way:

### Method: Direct URL Access
Simply navigate to: `/admin-secret-panel`

Example: `http://your-domain.com/admin-secret-panel`

### Login Credentials
- **Username:** admin
- **Password:** admin123

## Admin Panel Features

Once logged in, you can:

1. **View Statistics**
   - Total number of books
   - Featured books count
   - Books with active offers

2. **Add New Books**
   - Upload book details (title, author, price, image, description)
   - Set category (Fiction, Poetry, Literature, Biography, History)
   - Add ISBN, page count, and format
   - Upload book cover image URL

3. **Manage Offers**
   - Set offer percentage (0-90%)
   - Automatically calculates discounted price
   - Shows savings amount
   - Displays offer badge on the main website

4. **Feature Books**
   - Mark books as "Featured" with a star icon
   - Featured books display prominently on the website
   - Toggle feature status with one click

5. **Edit Books**
   - Update any book details
   - Change pricing and offers
   - Modify category and metadata

6. **Delete Books**
   - Remove books from the catalog
   - Confirmation prompt to prevent accidents

## Important Notes

- All book data is stored in browser localStorage
- Custom books added through admin panel persist across sessions
- Featured and offer settings are immediately reflected on the main website
- Discounted prices are automatically calculated and displayed
- Admin authentication is also stored in localStorage for convenience

## Security Note

In a production environment, you should:
- Use server-side authentication
- Store credentials securely (hashed passwords)
- Implement proper access control
- Use HTTPS for all admin panel access
- Add session timeout features
- Implement proper database storage instead of localStorage
