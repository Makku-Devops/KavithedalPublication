import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { HeroCarousel } from './components/HeroCarousel';
import { TrendingBooks } from './components/TrendingBooks';
import { NewArrivals } from './components/NewArrivals';
import { RelatedBooks } from './components/RelatedBooks';
import { CategorySection } from './components/CategorySection';
import { ContactUs } from './components/ContactUs';
import { Footer } from './components/Footer';
import { BookDetail } from './components/BookDetail';
import { Checkout } from './components/Checkout';
import { PaymentSuccess } from './components/PaymentSuccess';
import { OrderTracking } from './components/OrderTracking';
import { Cart, CartItem } from './components/Cart';
import { NotificationPanel } from './components/NotificationPanel';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';
import { Toaster } from './components/ui/sonner';
import { getBookById, getRelatedBooks, allBooks as initialBooks } from './data/booksData';
import { toast } from 'sonner@2.0.3';

type AppView = 'home' | 'detail' | 'checkout' | 'payment-success' | 'tracking' | 'cart' | 'admin';
type ActiveSection = 'home' | 'books' | 'contact' | 'category';

interface Book {
  id: number;
  title: string;
  price: number;
  image: string;
  onSale: boolean;
  offer?: string;
  category: string;
  isFeatured?: boolean;
  offerPercentage?: number;
  description?: string;
  author?: string;
  isbn?: string;
  pages?: number;
  format?: string;
}

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [activeSection, setActiveSection] = useState<ActiveSection>('home');
  const [selectedBookId, setSelectedBookId] = useState<number | null>(null);
  const [orderDetails, setOrderDetails] = useState<{ quantity: number; total: number } | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [allBooks, setAllBooks] = useState<Book[]>(initialBooks);

  // Check for admin authentication on mount
  useEffect(() => {
    const adminAuth = localStorage.getItem('adminAuth');
    if (adminAuth === 'true') {
      setIsAdminAuthenticated(true);
    }

    // Load custom books from localStorage
    const savedBooks = localStorage.getItem('customBooks');
    if (savedBooks) {
      try {
        const customBooks = JSON.parse(savedBooks);
        setAllBooks([...customBooks, ...initialBooks]);
      } catch (e) {
        console.error('Failed to load custom books');
      }
    }

    // Check for admin URL
    if (window.location.pathname === '/admin-secret-panel') {
      setCurrentView('admin');
    }
  }, []);

  // Save custom books to localStorage whenever they change
  const saveCustomBooks = (books: Book[]) => {
    const customBooks = books.filter(book => !initialBooks.find(b => b.id === book.id));
    localStorage.setItem('customBooks', JSON.stringify(customBooks));
  };

  const handleBookClick = (bookId: number) => {
    setSelectedBookId(bookId);
    setCurrentView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setSelectedBookId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBuyNow = () => {
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromCheckout = () => {
    setCurrentView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePaymentComplete = (quantity: number, total: number) => {
    setOrderDetails({ quantity, total });
    setCurrentView('payment-success');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePaymentSuccessComplete = () => {
    setCurrentView('tracking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (bookId: number, quantity: number = 1) => {
    const book = getBookById(bookId);
    if (!book) return;

    setCartItems((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === bookId);
      
      if (existingItem) {
        toast.success(`Updated ${book.title} quantity in cart`);
        return prevCart.map((item) =>
          item.id === bookId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        toast.success(`Added ${book.title} to cart`);
        return [
          ...prevCart,
          {
            id: book.id,
            title: book.title,
            price: book.price,
            image: book.image,
            quantity,
          },
        ];
      }
    });
  };

  const handleUpdateCartQuantity = (bookId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setCartItems((prevCart) =>
      prevCart.map((item) =>
        item.id === bookId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveFromCart = (bookId: number) => {
    const book = getBookById(bookId);
    setCartItems((prevCart) => prevCart.filter((item) => item.id !== bookId));
    if (book) {
      toast.success(`Removed ${book.title} from cart`);
    }
  };

  const handleCartClick = () => {
    setCurrentView('cart');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCheckoutFromCart = (bookId: number) => {
    setSelectedBookId(bookId);
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNotificationClick = () => {
    setIsNotificationOpen(!isNotificationOpen);
  };

  const handleNavigate = (section: string) => {
    setActiveSection(section as ActiveSection);
    setCurrentView('home');
    setSearchQuery('');
    setSearchResults([]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    const results = allBooks.filter((book) =>
      book.title.toLowerCase().includes(query.toLowerCase())
    );
    setSearchResults(results);
    setActiveSection('books');
    toast.success(`Found ${results.length} book(s) matching "${query}"`);
  };

  // Admin functions
  const handleAdminLogin = () => {
    setIsAdminAuthenticated(true);
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    setCurrentView('home');
    setActiveSection('home');
  };

  const handleAddBook = (book: Book) => {
    const updatedBooks = [...allBooks, book];
    setAllBooks(updatedBooks);
    saveCustomBooks(updatedBooks);
  };

  const handleUpdateBook = (updatedBook: Book) => {
    const updatedBooks = allBooks.map(book => 
      book.id === updatedBook.id ? updatedBook : book
    );
    setAllBooks(updatedBooks);
    saveCustomBooks(updatedBooks);
  };

  const handleDeleteBook = (bookId: number) => {
    const updatedBooks = allBooks.filter(book => book.id !== bookId);
    setAllBooks(updatedBooks);
    saveCustomBooks(updatedBooks);
  };

  const selectedBook = selectedBookId ? allBooks.find(b => b.id === selectedBookId) : null;
  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Admin Panel View
  if (currentView === 'admin') {
    if (!isAdminAuthenticated) {
      return (
        <>
          <Toaster />
          <AdminLogin onLogin={handleAdminLogin} />
        </>
      );
    }
    return (
      <>
        <Toaster />
        <AdminDashboard
          onLogout={handleAdminLogout}
          books={allBooks}
          onAddBook={handleAddBook}
          onUpdateBook={handleUpdateBook}
          onDeleteBook={handleDeleteBook}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Toaster />
      <NotificationPanel 
        isOpen={isNotificationOpen} 
        onClose={() => setIsNotificationOpen(false)} 
      />
      <Header 
        cartItemCount={cartItemCount} 
        onCartClick={handleCartClick}
        onNotificationClick={handleNotificationClick}
        onSearch={handleSearch}
      />
      <Navigation 
        activeSection={activeSection}
        onNavigate={handleNavigate}
      />
      
      {currentView === 'home' && activeSection === 'home' && (
        <main>
          <HeroCarousel />
          <TrendingBooks 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
          <NewArrivals 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
          <RelatedBooks 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
        </main>
      )}

      {currentView === 'home' && activeSection === 'books' && (
        <main>
          {searchQuery && searchResults.length > 0 ? (
            <section className="max-w-7xl mx-auto px-6 py-12">
              <h2 className="text-emerald-800 mb-2">Search Results for "{searchQuery}"</h2>
              <p className="text-gray-600 mb-8">Found {searchResults.length} book(s)</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {searchResults.map((book) => (
                  <div key={book.id}>
                    <div className="cursor-pointer" onClick={() => handleBookClick(book.id)}>
                      <img src={book.image} alt={book.title} className="w-full aspect-[2/3] object-cover rounded-lg mb-3" />
                      <h3 className="line-clamp-2">{book.title}</h3>
                      <p className="text-emerald-700">₹ {book.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ) : searchQuery && searchResults.length === 0 ? (
            <section className="max-w-7xl mx-auto px-6 py-12 text-center">
              <h2 className="text-emerald-800 mb-4">No Results Found</h2>
              <p className="text-gray-600 mb-8">No books found matching "{searchQuery}"</p>
            </section>
          ) : (
            <>
              <TrendingBooks 
                onBookClick={handleBookClick}
                onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
              />
              <NewArrivals 
                onBookClick={handleBookClick}
                onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
              />
              <RelatedBooks 
                onBookClick={handleBookClick}
                onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
              />
            </>
          )}
        </main>
      )}

      {currentView === 'home' && activeSection === 'category' && (
        <main>
          <CategorySection 
            onBookClick={handleBookClick}
            onAddToCart={(bookId) => handleAddToCart(bookId, 1)}
          />
        </main>
      )}

      {currentView === 'home' && activeSection === 'contact' && (
        <main>
          <ContactUs />
        </main>
      )}

      {currentView === 'detail' && selectedBook && (
        <BookDetail
          book={selectedBook}
          relatedBooks={getRelatedBooks(selectedBookId!)}
          onBack={handleBackToHome}
          onBookClick={handleBookClick}
          onBuyNow={handleBuyNow}
          onAddToCart={handleAddToCart}
          onAddRelatedToCart={(bookId) => handleAddToCart(bookId, 1)}
        />
      )}

      {currentView === 'cart' && (
        <Cart
          cartItems={cartItems}
          onUpdateQuantity={handleUpdateCartQuantity}
          onRemoveItem={handleRemoveFromCart}
          onBack={handleBackToHome}
          onCheckout={handleCheckoutFromCart}
        />
      )}

      {currentView === 'checkout' && selectedBook && (
        <Checkout
          book={selectedBook}
          onBack={handleBackFromCheckout}
          onPaymentComplete={handlePaymentComplete}
        />
      )}

      {currentView === 'payment-success' && orderDetails && (
        <PaymentSuccess
          totalAmount={orderDetails.total}
          onComplete={handlePaymentSuccessComplete}
        />
      )}

      {currentView === 'tracking' && selectedBook && orderDetails && (
        <OrderTracking
          book={selectedBook}
          quantity={orderDetails.quantity}
          totalAmount={orderDetails.total}
          onBackToHome={handleBackToHome}
        />
      )}
      
      {currentView !== 'payment-success' && <Footer />}
    </div>
  );
}
