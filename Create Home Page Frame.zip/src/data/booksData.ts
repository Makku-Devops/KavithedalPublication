import { trendingBooks } from '../components/TrendingBooks';
import { newArrivals } from '../components/NewArrivals';
import { relatedBooks } from '../components/RelatedBooks';

export interface Book {
  id: number;
  title: string;
  price: number;
  image: string;
  onSale: boolean;
  description?: string;
  author?: string;
  isbn?: string;
  pages?: number;
  format?: string;
  weight?: string;
  dimensions?: string;
}

// Combine all books
const allBooksArray = [
  ...trendingBooks,
  ...newArrivals,
  ...relatedBooks,
];

// Export as array for searching
export const allBooks = allBooksArray;

// Create a map for easy lookup
const allBooksMap: Record<number, Book> = allBooksArray.reduce((acc, book) => {
  acc[book.id] = {
    ...book,
    description: 'உலகின் முதன்மையான ஒரு அதிசிய செய்தி அன்பு! அன்பே வாழ்க்கையின் முழுமையான இருக்கிறது. இந்த நூல் இரு நிகழ்ச்சிகளையும் முழுமையாக கொண்டுள்ளது. முதலாம் நிகழ்வு சற்று புதிரானது, அதில் பல வித்தியாசமான செய்திகள் உள்ளன. இரண்டாம் நிகழ்வு முதலாம் நிகழ்வை விட தெளிவானது மற்றும் புரிந்து கொள்ள எளிதானது.',
    author: 'மருதமுத்து செல்வராஜ் செல்வம்',
    isbn: '9789384303181',
    pages: 120,
    format: 'Paperback',
    weight: '0.2 g',
    dimensions: '8.3 × 5.3 × 0.6 cm',
  };
  return acc;
}, {} as Record<number, Book>);

export function getBookById(id: number): Book | undefined {
  return allBooksMap[id];
}

export function getRelatedBooks(currentBookId: number): Book[] {
  return allBooksArray
    .filter(book => book.id !== currentBookId)
    .slice(0, 4);
}
